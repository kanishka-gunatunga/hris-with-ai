<?php

namespace Smalot\PdfParser\Exception;

class EncodingNotFoundException extends \Exception
{
}
